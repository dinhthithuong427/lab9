<?php 
// Khởi tạo kết nối đến MySQL Server (Hostname, Username, Password, Database)
$connect = mysqli_connect('localhost', 'root', '', 'tintuc');

// Kiểm tra nếu có lỗi kết nối thì dừng chương trình và in ra thông báo lỗi
if (mysqli_connect_errno() !== 0) {
    die("Error: Could not connect to the database. An error " . mysqli_connect_error() . " occurred.");
}

// Thiết lập mã tiếng Việt UTF-8 cho kết nối CSDL
mysqli_set_charset($connect, 'utf8');
?>