<?php
session_start();
if(isset($_POST['login'])){
    include('connect.php'); // File kết nối CSDL của bạn
    $name = $_POST['username'];
    $pass = $_POST['password'];
    
    $sl = "select * from users where Username='".$name."' and Password='".$pass."'";
    $result = mysqli_query($connect, $sl);
    $kt = mysqli_num_rows($result);
    
    if($kt > 0){
        // Nếu đúng, lưu thông tin vào Session
        $_SESSION['username'] = $name;
        $_SESSION['password'] = $pass;    
        
        echo "<script>alert('Login Successfull.'); location.href='trangquantriadmin.php';</script>";
    } else {
        echo "<script>alert('Login Failed.'); location.href='dangnhap.php';</script>";
    }
}
?>