<?php
session_start();
session_destroy(); // Hủy toàn bộ session
echo "<script>alert('Logout Successfull.'); location.href='dangnhap.php';</script>";
?>