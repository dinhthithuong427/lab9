<?php 
session_start(); // Bắt buộc phải có hàm này ở đầu trang để khởi động session

// Nếu chưa có session 'name' thì tiến hành khởi tạo
if(!isset($_SESSION['name'])) {
    $_SESSION['name'] = "hocweb.com.vn";
    $_SESSION['age'] = 120;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Session</title>
</head>
<body>
<?php
// Xuất giá trị của session ra màn hình
echo "Tên bạn là: " . $_SESSION['name'] . "<br/>";
echo "Số tuổi của bạn: " . $_SESSION['age'] . "<br/>";
?>
<a href="test_session.php">Click here!</a>
</body>
</html>