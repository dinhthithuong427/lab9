<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Test Session</title>
</head>
<body>
<?php
// Vẫn lấy được dữ liệu từ trang trước truyền sang
echo "Chào bạn " . $_SESSION['name'] . " có tuổi là: " . $_SESSION['age'];
?>
<br />
<a href="huy_session.php">Hủy session</a>
</body>
</html>