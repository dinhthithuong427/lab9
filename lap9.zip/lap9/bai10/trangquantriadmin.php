<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Trang quản trị admin</title>
</head>
<body>
    <h2>Trang Quản Trị</h2>
    <?php
    // Kiểm tra xem đã đăng nhập hay chưa bằng Session
    if(isset($_SESSION['username']) && isset($_SESSION['password'])) {
        echo "Xin chào: " . $_SESSION['username'];
        echo "<br><a href='logout.php'>Logout (Thoát)</a>";
    } else {
        // Nếu chưa đăng nhập mà gõ link vào trực tiếp -> Báo lỗi và chuyển hướng
        echo "<script>alert('Bạn chưa đăng nhập'); location.href='dangnhap.php';</script>";
    }
    ?>
</body>
</html>