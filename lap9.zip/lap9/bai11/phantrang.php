<?php
// Kết nối CSDL phantrang
$conn = mysqli_connect("localhost", "root", "", "phantrang");

// Kiểm tra trang hiện tại (nếu chưa có trên URL thì mặc định là trang 1)
if(isset($_GET['page'])){
    $page = $_GET['page'];
} else {
    $page = 1;
}

$limit = 10; // Giới hạn hiển thị 10 tiêu đề tin tức trên mỗi trang
$start = ($page - 1) * $limit; // Tính vị trí bắt đầu lấy dữ liệu

// Lấy tổng số lượng tin tức có trong bảng
$total_title = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM tintuc"));
// Tính tổng số trang cần hiển thị
$total_page = ceil($total_title / $limit);

// Truy vấn lấy giới hạn dữ liệu theo trang
$query = "SELECT * FROM tintuc LIMIT ".$start.", ".$limit;
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Phân trang trong PHP</title>
    <style type="text/css">
        body {
            background: #ecf0f1;
            font-family: Arial, sans-serif;
        }
        a:link, a:visited {
            text-decoration: none;
        }
        a:hover {
            color: #f00;
        }
        .title, .pagination {
            width: 600px;
            margin: 0 auto;
            margin-bottom: 20px;
            text-align: center;
        }
        .title {
            background: #3498db;
            padding: 20px;
            line-height: 1.5;
            text-align: left;
            border-radius: 5px;
        }
        .title a {
            color: #fff;
        }
        .title a:hover {
            color: #e67e22;
        }
        .pagination a {
            color: #2980b9;
            font-weight: bold;
            padding: 5px 8px;
        }
    </style>
</head>
<body>

    <!-- Hiển thị danh sách tin tức của trang hiện tại -->
    <div class="title">
        <?php
        while($row = mysqli_fetch_array($result)){
            echo '<a href="#">'.$row['id'].'. '.$row['title'].'</a><br />';
        }
        ?>
    </div>

    <!-- Hiển thị các nút số trang phân trang bên dưới -->
    <div class="pagination">
        <?php
        for($i = 1; $i <= $total_page; $i++){
            // Nếu là trang hiện tại có thể định dạng nổi bật hơn, ở đây in ra danh sách các trang
            echo '<a href="phantrang.php?page='.$i.'">'.$i.'</a> | ';
        }
        ?>
    </div>

</body>
</html>