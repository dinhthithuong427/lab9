<?php
// Định nghĩa header của trang PHP ở dạng XML
header("Content-type: text/xml");

// Kết nối đến CSDL rss
$conn = mysqli_connect("localhost", "root", "", "rss") or die("Khong thể kết nối CSDL");
mysqli_set_charset($conn, "utf8");

// Truy vấn lấy danh sách tin tức
$query = "SELECT * FROM news";
$result = mysqli_query($conn, $query);

$item = "";
while($row = mysqli_fetch_array($result)){
    $item .= '<item>';
    $item .= '<title>'.$row['title'].'</title>';
    $item .= '<link>'.$row['link'].'</link>';
    $item .= '<description>'.$row['description'].'</description>';
    $item .= '</item>';
}

// Xuất cấu trúc file RSS chuẩn XML ra màn hình
echo('<?xml version="1.0" encoding="UTF-8"?>');
echo('<rss version="2.0">');
echo("<channel>");
echo("<title>Học Web | Học làm web pro</title>");
echo("<link>http://hocweb.com.vn</link>");
echo("<description>Website hocweb.com.vn được hình thành từ ý tưởng giúp các em sinh viên có một nơi học tập thực tế gắn với nhu cầu doanh nghiệp</description>");
echo $item;
echo("</channel>");
echo('</rss>');
?>