<?php
session_start();
$message = "";

// Xử lý khi người dùng bấm nút Submit form
if(isset($_POST['submit'])) {
    $user_captcha = trim($_POST['captcha']); // Lấy giá trị người dùng nhập vào
    
    // Kiểm tra so sánh chuỗi người dùng nhập với Session captcha đã lưu
    if(isset($_SESSION['captcha']) && $user_captcha == $_SESSION['captcha']) {
        $message = "<p style='color: green;'>Chính xác! Bạn đã nhập đúng mã CAPTCHA.</p>";
    } else {
        $message = "<p style='color: red;'>Sai mã CAPTCHA, vui lòng nhập lại!</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ví dụ tạo CAPTCHA trong PHP</title>
</head>
<body>
    <h2>Form Đăng Ký / Gửi Liên Hệ</h2>
    
    <!-- Hiển thị thông báo kết quả kiểm tra -->
    <?php echo $message; ?>

    <form action="" method="post">
        <table>
            <tr>
                <td>Họ tên:</td>
                <td><input type="text" name="fullname" required></td>
            </tr>
            <tr>
                <td>Mã xác nhận:</td>
                <td>
                    <!-- Gọi file captcha.php để hiển thị ảnh -->
                    <img src="captcha.php" alt="CAPTCHA code" style="vertical-align: middle; border: 1px solid #ccc;" />
                    <br><br>
                    <input type="text" name="captcha" placeholder="Nhập lại các ký tự trên" required>
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Gửi đi"></td>
            </tr>
        </table>
    </form>
</body>
</html>