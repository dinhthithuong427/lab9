<?php
// Kết nối cơ sở dữ liệu
$conn = mysqli_connect("localhost", "root", "", "poll") or die("Không thể kết nối CSDL");
mysqli_set_charset($conn, "utf8");

$question_id = 1; // Mặc định lấy câu hỏi số 1
$success_msg = "";

// Xử lý khi người dùng bấm nút Gửi bình chọn (Vote)
if(isset($_POST['submit_vote'])) {
    if(isset($_POST['answer'])) {
        $answer_id = $_POST['answer'];
        // Tăng số lượt vote (votes) lên 1 đơn vị cho đáp án được chọn
        $update_query = "UPDATE poll_answers SET votes = votes + 1 WHERE id = $answer_id";
        mysqli_query($conn, $update_query);
        $success_msg = "<p style='color: green;'>Cảm ơn bạn đã bình chọn!</p>";
    } else {
        $success_msg = "<p style='color: red;'>Vui lòng chọn một phương án trước khi bình chọn!</p>";
    }
}

// Lấy thông tin câu hỏi
$q_result = mysqli_query($conn, "SELECT * FROM poll_questions WHERE id = $question_id");
$question_row = mysqli_fetch_array($q_result);

// Lấy danh sách các đáp án và tổng số lượt bình chọn
$a_result = mysqli_query($conn, "SELECT * FROM poll_answers WHERE question_id = $question_id");
$total_votes_query = mysqli_query($conn, "SELECT SUM(votes) as total FROM poll_answers WHERE question_id = $question_id");
$total_row = mysqli_fetch_array($total_votes_query);
$total_votes = $total_row['total'] > 0 ? $total_row['total'] : 1; // Tránh lỗi chia cho 0
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Hệ thống Bình chọn trực tuyến</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f7;
            margin: 50px;
        }
        .poll-container {
            width: 450px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            margin: 0 auto;
        }
        h3 {
            color: #2c3e50;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin-bottom: 10px;
        }
        .progress-bar {
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            height: 15px;
            margin-top: 5px;
        }
        .progress-fill {
            background: #3498db;
            height: 100%;
            width: 0%;
        }
        .vote-btn {
            background: #27ae60;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 15px;
        }
        .vote-btn:hover {
            background: #219653;
        }
    </style>
</head>
<body>

<div class="poll-container">
    <h3><?php echo $question_row['question']; ?></h3>
    <?php echo $success_msg; ?>

    <form action="" method="post">
        <ul>
            <?php 
            // Hiển thị danh sách đáp án dưới dạng Radio button kèm kết quả tỷ lệ
            while($answer_row = mysqli_fetch_array($a_result)) {
                $percentage = round(($answer_row['votes'] / $total_votes) * 100);
                echo '<li>';
                echo '<label><input type="radio" name="answer" value="'.$answer_row['id'].'"> '.$answer_row['answer'].'</label>';
                echo '<br><small>('.$answer_row['votes'].' lượt bình chọn - '.$percentage.'%)</small>';
                echo '<div class="progress-bar"><div class="progress-fill" style="width: '.$percentage.'%;"></div></div>';
                echo '</li>';
            }
            ?>
        </ul>
        <input type="submit" name="submit_vote" value="Bình chọn" class="vote-btn">
    </form>
</div>

</body>
</html>