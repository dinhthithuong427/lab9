<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Sử dụng CKEditor</title>
    <!-- Sử dụng bản CDN 4.22.1 miễn phí, không bị lỗi bản quyền -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.22.1/ckeditor.js"></script>
</head>
<body>
<form action="_posteddata.php" method="post">
    <textarea name="tomtat" id="tomtat" cols="30" rows="10"></textarea>
    
    <script type="text/javascript">
        CKEDITOR.replace('tomtat');
    </script>
    
    <br>
    <input name="ok" type="submit" value="Ok" />
</form>
</body>
</html>